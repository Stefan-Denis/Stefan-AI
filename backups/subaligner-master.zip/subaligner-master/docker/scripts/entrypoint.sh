#!/bin/bash

source /venv/bin/activate
exec "$@"
