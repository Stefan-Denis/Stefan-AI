########################
Test
########################

**Run unit tests**::

    $ make test

**Run test coverage**::

    $ make coverage

**Run tests with target Python versions**::

    $ make test-all

**Run integration tests**::

    $ make test-int
