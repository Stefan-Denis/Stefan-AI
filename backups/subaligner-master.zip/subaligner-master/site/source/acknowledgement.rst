########################
Acknowledgement
########################

**This tool wouldn't be possible without the following packages**::

    - `librosa <https://librosa.github.io/librosa/>`_
    - `tensorflow <https://www.tensorflow.org/>`_
    - `scikit-learn <https://scikit-learn.org>`_
    - `pycaption <https://pycaption.readthedocs.io>`_
    - `pysrt <https://github.com/byroot/pysrt>`_
    - `pysubs2 <https://github.com/tkarabela/pysubs2>`_
    - `aeneas <https://www.readbeyond.it/aeneas/>`_
    - `transformers <https://huggingface.co/transformers/>`_
    - `openai-whisper <https://github.com/openai/whisper>`_

Thanks to Alan Robinson and Nigel Megitt for their invaluable feedback.
