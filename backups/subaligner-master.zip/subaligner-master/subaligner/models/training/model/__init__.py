"""This folder contains the model."""
