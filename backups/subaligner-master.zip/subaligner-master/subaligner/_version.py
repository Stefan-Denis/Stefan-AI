"""The semver for the current release."""
__version__ = "0.3.5"
